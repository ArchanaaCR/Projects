package com.maveric.tsp.mediaService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


class MediaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
