package com.maveric.tsp.mentorshipService.entities;

public enum Action {
    MENTOR_ACCEPT,
    MANAGER_ACCEPT,
    MENTOR_REJECT,
    MANAGER_REJECT

}
