package com.maveric.tsp.mentorshipService.entities;

public enum RequestStatus {
    ACCEPTED,
    DECLINED
}
