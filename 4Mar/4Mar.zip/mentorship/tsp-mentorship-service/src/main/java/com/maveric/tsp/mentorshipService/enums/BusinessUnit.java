package com.maveric.tsp.mentorshipService.enums;

public enum BusinessUnit {
    DATA,DIGITAL,QE,CORE
}
