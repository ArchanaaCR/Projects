package com.maveric.tsp.mentorshipService.enums;

public enum Domain {

    CORE_BANKING, RETAIL_BANKING, INSURANCE
}
