package com.maveric.tsp.mentorshipService.enums;

public enum SkillCategory {
    FRONTEND, BACKEND, UI_UX, FULLSTACK;
}
