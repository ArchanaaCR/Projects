package com.maveric.tsp.notifyservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotifyServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(NotifyServiceApplication.class, args);
	}
}
