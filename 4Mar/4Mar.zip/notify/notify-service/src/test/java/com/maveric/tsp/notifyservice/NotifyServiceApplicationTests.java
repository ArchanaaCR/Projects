package com.maveric.tsp.notifyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class NotifyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
