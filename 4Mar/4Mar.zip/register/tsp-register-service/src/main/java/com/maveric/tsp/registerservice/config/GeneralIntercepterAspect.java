package com.maveric.tsp.registerservice.config;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Slf4j
@Component
public class GeneralIntercepterAspect {

    @Pointcut("execution(* com.maveric.tsp.registerservice.controller.*.*(..))")
    public void loggingPointCut(){}

    @Before("loggingPointCut()")
    public void before(JoinPoint joinPoint){
        log.info("This is executing before logginpointcut"+joinPoint.getSignature());
    }

    @After("loggingPointCut()")
    public void after(JoinPoint joinPoint){
        log.info("This is executing after regardless of result in logginpointcut"+joinPoint.getSignature());
    }
    @AfterReturning("loggingPointCut()")
    public void afterFinal(JoinPoint joinPoint){
        log.info("This is executing after getting success in logginpointcut"+joinPoint.getSignature());
    }
    @Around("loggingPointCut()")
    public  void around(JoinPoint joinPoint){
        log.info("this will be executed irrespective of method execution"+joinPoint.getSignature());
    }
    @AfterThrowing("loggingPointCut()")
    public void afterThrowing(JoinPoint joinPoint){
        log.info("This is executing after getting the exception in logginpointcut"+joinPoint.getSignature());
    }
}
