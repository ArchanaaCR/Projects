package com.maveric.tsp.registerservice.exception;

public class CustomExceptions extends RuntimeException{
    public CustomExceptions(String message) {
        super(message);
    }
}
