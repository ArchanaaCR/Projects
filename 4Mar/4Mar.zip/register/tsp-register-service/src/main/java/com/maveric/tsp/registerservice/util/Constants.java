package com.maveric.tsp.registerservice.util;

public class Constants {

    public static final String FORGOT_PASSWORD_SUCCESS_MSG="New system generated password has been sent to your mail id";
    public static final String DELETE_SUCCESS_MSG="User’s Successfully Deleted";
    public static final String RESET_PASSWORD_SUCCESS_MSG="Your new password has been updated successfully";

    public static final String PROFILE_STATUS_UNAVAILABLE="UNAVAILABLE";

}
