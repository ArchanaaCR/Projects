package com.maveric.tsp.reportService.dtos;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;


@Data
@NoArgsConstructor
public class Session {

    private Long sessionId;

    private String mentorEmailId;

    private String menteeEmailId;

    private String managerEmailId;

    private String sessionTopic;
    /**
     * Requested date for a mentorship session.
     */

    private LocalDateTime fromDate;
    private LocalDateTime toDate;

    private Boolean managerApproval;

    private Boolean mentorApproval;

    private String managerComments;

    private String mentorComments;

    private String sessionStatus;//Request/Scheduled/completed/Rejected.

    private String requestStatus; //accepted/decliend

    private String mentorshipStatus; //active/closed
    private Integer totalSessionCovered;
    private Integer sessionDuration;
    private LocalDate startDate;
    private String requestCurrentlyWith;
    private LocalDate createdDate;
    private String createdBy;
    private LocalDate updatedDate;
    private String updatedBy;
    private LocalDateTime availableDate_1;
    private LocalDateTime availableDate_2;
    private LocalDateTime scheduledDate;
}
