package com.maveric.tsp.reportService.exception;

public class NoDataFoundException extends RuntimeException {
    public NoDataFoundException(String s) {
        super(s);
    }
}
