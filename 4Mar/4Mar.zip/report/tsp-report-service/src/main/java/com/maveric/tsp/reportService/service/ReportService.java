package com.maveric.tsp.reportService.service;

import com.maveric.tsp.reportService.dtos.ReportRequestDto;
import com.maveric.tsp.reportService.dtos.Session;
import com.maveric.tsp.reportService.dtos.User;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public interface ReportService {
    /**
     *
     * @param reportRequestDto
     * @return
     * @throws IOException
     */
    ArrayList<User> getDataDownloaded(ReportRequestDto reportRequestDto) throws IOException;


    List<Session> getMentorDetails(ReportRequestDto reportRequestDto);
}
