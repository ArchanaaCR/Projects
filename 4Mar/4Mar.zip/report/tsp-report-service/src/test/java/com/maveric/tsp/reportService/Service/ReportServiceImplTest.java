package com.maveric.tsp.reportService.Service;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.maveric.tsp.reportService.client.IRegisterServiceApi;
import com.maveric.tsp.reportService.client.IUserServiceApi;
import com.maveric.tsp.reportService.dtos.*;
import com.maveric.tsp.reportService.service.Impl.ReportServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ReportServiceImplTest {


    @Mock
    private IRegisterServiceApi registerServiceApi;

    @Mock
    private IUserServiceApi userServiceApi;

    @InjectMocks
    @Spy
    private ReportServiceImpl reportService;

    private static ObjectMapper objectMapper=new ObjectMapper();

    private static ReportRequestDto reportRequestDto;
    private static User user;
    private static UserProfileResponseDto userProfileResponseDto;
    private static UserDetailsDto userDetailsDto;

    @BeforeAll
    public static void setUp(){
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
        objectMapper.registerModule(new JavaTimeModule());
        try {
            reportRequestDto = objectMapper.readValue(new File("src/test/resources/ReportRequest.json"), ReportRequestDto.class);
            user=objectMapper.readValue(new File("src/test/resources/User.json"), User.class);
            userProfileResponseDto=objectMapper.readValue(new File("src/test/resources/UserProfileResponse.json"), UserProfileResponseDto.class);
            userDetailsDto= objectMapper.readValue(new File("src/test/resources/UserDetails.json"), UserDetailsDto.class);
        } catch (IOException e) {
            log.info("Json Parsing Exception:"+e.getMessage());
        }
    }

    @Test
    void test_getDataDownloaded() throws Exception {
        ArrayList<User> expected = new ArrayList<>();
        expected.add(user);

        ResponseDto<UserProfileResponseDto> responseDto = new ResponseDto<>();
        responseDto.setPayLoad(userProfileResponseDto);
        ResponseEntity<ResponseDto<UserProfileResponseDto>> userProfileUpdateDto = ResponseEntity.ok(responseDto);

        ResponseDto<ArrayList<UserDetailsDto> > responseDto1 = new ResponseDto<>();
        responseDto1.setPayLoad(new ArrayList(Arrays.asList(userDetailsDto)));
        ResponseEntity<ResponseDto<ArrayList<UserDetailsDto>>> userDetailsDtoList = ResponseEntity.ok(responseDto1);

        when(userServiceApi.getUserProfileByEmailId(anyString())).thenReturn(userProfileUpdateDto);
        when(registerServiceApi.fetchUsersBetweenDataRange(reportRequestDto)).thenReturn(userDetailsDtoList);

        ArrayList<User> actual = reportService.getDataDownloaded(reportRequestDto);

        verify(registerServiceApi, times(1)).fetchUsersBetweenDataRange(reportRequestDto);
        verify(userServiceApi, times(1)).getUserProfileByEmailId(anyString());

        assertEquals(expected, actual);
    }
}
