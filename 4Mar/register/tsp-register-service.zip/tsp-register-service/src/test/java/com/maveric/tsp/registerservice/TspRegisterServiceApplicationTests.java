package com.maveric.tsp.registerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

class TspRegisterServiceApplicationTests {
}
