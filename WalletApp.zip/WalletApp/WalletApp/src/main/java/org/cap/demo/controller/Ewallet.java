package org.cap.demo.controller;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.demo.model.Customer;
import org.cap.demo.service.CustomerServiceImp;
import org.cap.demo.service.ICustomerService;


@WebServlet("/LoginServlet")
public class Ewallet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ICustomerService customerservice;

	public Ewallet() {

		customerservice=new CustomerServiceImp();
	}


	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}


	public void destroy() {
		// TODO Auto-generated method stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {


		String user=request.getParameter("userName");
		String password=request.getParameter("userPwd");

		Customer customer=new Customer();


		if(customerservice.validateLogin(customer))
			response.sendRedirect("pages/success.html");
		else
			response.sendRedirect("index.html");
	}




}
