package org.cap.demo.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.demo.model.Address;
import org.cap.demo.model.Customer;
import org.cap.demo.service.CustomerServiceImp;
import org.cap.demo.service.ICustomerService;

@WebServlet("/RegisterUserServelet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   private ICustomerService customerservice;
    public RegisterServlet() {
       
       customerservice=new CustomerServiceImp();
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response, String conatctNo) 
			throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String contactNo=request.getParameter("contactNo");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		Customer customer=new Customer(firstName, lastName, email, password, contactNo);
		
		String addressLine1=request.getParameter("addressLine1");
		String addressLine2=request.getParameter("addressLine2");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String zipCode=request.getParameter("zipcode");
		Address address=new Address(addressLine1,addressLine2, city, state, zipCode,customer);
	}

}
