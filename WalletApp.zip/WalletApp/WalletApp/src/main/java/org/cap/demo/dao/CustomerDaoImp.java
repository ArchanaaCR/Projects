package org.cap.demo.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.demo.model.Address;
import org.cap.demo.model.Customer;

public class CustomerDaoImp implements ICustomerDao{

	@Override
	public boolean addCustomer(Customer customer,Address address) {
		
		EntityManager entitymanager=getEntityManager();
		EntityTransaction entityTransaction=entitymanager.getTransaction();
		entityTransaction.begin();
				
		entitymanager.persist(customer);
		entitymanager.persist(address);
		entityTransaction.commit();
		entitymanager.close();
		
		
		return false;
	}
	
	private EntityManager getEntityManager() {
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("capg");
		
		return entityManagerFactory.createEntityManager();
	}
}
