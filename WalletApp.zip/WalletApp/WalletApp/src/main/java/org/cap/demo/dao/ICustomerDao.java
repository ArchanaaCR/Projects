package org.cap.demo.dao;

import org.cap.demo.model.Address;
import org.cap.demo.model.Customer;

public interface ICustomerDao {

	boolean addCustomer(Customer customer, Address address);

}
