package org.cap.demo.service;

import org.cap.demo.dao.CustomerDaoImp;
import org.cap.demo.dao.ICustomerDao;
import org.cap.demo.model.Address;
import org.cap.demo.model.Customer;

public class CustomerServiceImp implements ICustomerService{

	ICustomerDao customerdao=new CustomerDaoImp();
	
	@Override
	public boolean addCustomer(Customer customer, Address address) {
		
		return customerdao.addCustomer(customer, address);
	}

	@Override
	public boolean validateLogin(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

}
