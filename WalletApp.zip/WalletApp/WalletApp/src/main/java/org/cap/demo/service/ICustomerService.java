package org.cap.demo.service;

import org.cap.demo.model.Address;
import org.cap.demo.model.Customer;

public interface ICustomerService {
	
	public boolean addCustomer(Customer customer, Address address);

	public boolean validateLogin(Customer customer);

}
