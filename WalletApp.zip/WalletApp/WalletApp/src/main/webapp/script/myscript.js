function registerFormValidation(){
	var firstName= register.firstName.value
	var contactno=register.contactNo.value
	var email=register.email.value
	var password=register.password.value
	var congfirmpassword=register.confirmpassword.value
	
	//validation first name
	if(firstName=="" || firstName==null ){
		
		document.getElementById("errFirstName").innerHTML='Please enter FirstName!'
		register.firstName.focus()
		return false
		}
		else{
			document.getElementById("errFirstName").innerHTML=''
		}
		
	//Validating conatct no
	if(contactno==""  || contactno.length!=10){
		document.getElementById("errcontactNo").innerHTML='Please enter 10 digits!'
		register.contactNo.focus()
		return false
		}
		else{
			document.getElementById("errcontactNo").innerHTML=''
		}
		//validating email
		if(!ValidateEmail(email)){
		document.getElementById("erreEmail").innerHTML='Please enter valid email!'
		register.email.focus()
		return false
		}
		else{
			document.getElementById("erreEmail").innerHTML=''
		}
		//validating pawword
		if(!checkPassword(password)){
		document.getElementById("errpwd").innerHTML='Please enter valid password'
		register.password.focus();
		return false
		}
		else{
			document.getElementById("errpwd").innerHTML=''
		}
	
		//Validating confirm password	
		if(confirmpassword=="" || confirmpassword == null || confirmpassword != password) {
		document.getElementById("errcon_pwd").innerHTML='Please confirm your password'
		register.confirm_password.focus();
		return false;
		} else{
		document.getElementById("errcon_pwd").innerHTML=''
		}
		return true
}




function ValidateEmail(mail) 
{
 if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))
  {
    return true
  }
  
    return false
}



function checkPassword(str)
{
    var re = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    return re.test(str);
}






function myfunc(){
	
	var userName=f1.userName.value
	var userPassword=f1.userPwd.value
	
	if(userName=="" || userName==null ){
		//alert('Please enter userName!')
		document.getElementById("userErrMsg").innerHTML='Please enter userName!'
		f1.userName.focus()
		return false
		}
		else{
			document.getElementById("userErrMsg").innerHTML=''
		}
	if(userPassword=="" || userPassword==null){
		//alert('Please enter userPassword!')
		document.getElementById("userPwdErrMsg").innerHTML='Please enter userPassword!'
		f1.userPwd.focus()
		return false
		}else{
			document.getElementById("userPwdErrMsg").innerHTML=''
		}
	
	return true
}
