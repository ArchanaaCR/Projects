package org.cap.WalletApplication.UserInterface;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import org.cap.WalletApplication.exceptionhandling.InvalidAccountIdException;
import org.cap.WalletApplication.exceptionhandling.InvalidContactNumberException;
import org.cap.WalletApplication.exceptionhandling.InvalidEmailIdException;
import org.cap.WalletApplication.exceptionhandling.InvalidFirstNameException;
import org.cap.WalletApplication.exceptionhandling.InvalidOpeniningBalanceException;
import org.cap.WalletApplication.exceptionhandling.InvalidPasswordException;
import org.cap.WalletApplication.exceptionhandling.InvalidaccountTypeException;
import org.cap.WalletApplication.exceptionhandling.InvalidaddressCityException;
import org.cap.WalletApplication.exceptionhandling.InvalidaddressLine1Exception;
import org.cap.WalletApplication.exceptionhandling.InvalidaddressStateException;
import org.cap.WalletApplication.exceptionhandling.InvalidaddressZipCodeException;
import org.cap.WalletApplication.model.Account;
import org.cap.WalletApplication.model.AccountType;
import org.cap.WalletApplication.model.Address;
import org.cap.WalletApplication.model.Customer;
import org.cap.WalletApplication.model.Transaction;
import org.cap.WalletApplication.model.TransactionType;

public class UserInterface {
	Scanner in=new Scanner(System.in);
	public int mainmenu()
	{
		System.out.println("1. Create account");
		System.out.println("2. Sign In");
		System.out.println("3. Sign Out");
		//		System.out.println("4. Exit");
		System.out.println("Enter the option from [1 to 3]");
		int choice=  in.nextInt();
		return choice;
	}
	String password=null, confirmPassword=null,firstName=null,customer_emailId=null,contact_number=null;
	Customer customer=new Customer();
	public Customer getCustomerDetails()
	{
		//Validating First Name
		do {
			System.out.println("Enter your First Name:");
			firstName=in.next();
			try {
				if(firstName==null || firstName==" ")
					throw new InvalidFirstNameException("First Name should not be Empty or NUll! Please enter firstName Again!");
			}
			catch(Exception e)
			{

			}
		}while(firstName==null || firstName==" ");


		customer.setCustomerFirstName(firstName);

		//Last Name
		System.out.println("Enter your Last Name:");
		customer.setCustomerLastName(in.next());

		// validating contact number
		do {
			System.out.println("Enter your Contact Number:");
			contact_number=in.next();
			try {
				if(!contact_number.matches("\\d{10}"))
					throw new InvalidContactNumberException("Contact Number should be in 10 digits! Please try Again!");
			}catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}while(!contact_number.matches("\\d{10}"));
		customer.setCustomer_number(contact_number);

		//Validating Email ID
		String regex_email="^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@" 
				+ "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
		do {

			System.out.println("Enter your EmailID:");
			customer_emailId=in.next();
			try {
				if(!customer_emailId.matches(regex_email))
					throw new InvalidEmailIdException("Wrong Email Id! Please try Again!");
			} 
			catch (InvalidEmailIdException e) {
				System.out.println(e.getMessage());}
		}while(!customer_emailId.matches(regex_email));
		customer.setCustomer_emailId(customer_emailId);


		//Validating Password
		String regex_password= "^(?=.*[0-9])"
				+ "(?=.*[a-z])(?=.*[A-Z])"
				+ "(?=.*[@#$%^&+=])"
				+ "(?=\\S+$).{8,20}$";
		do {
			try {

				System.out.println("Enter your password:");
				password=in.next();
				if (!password.matches(regex_password))
					throw new InvalidPasswordException("Wrong password. Password must contains 8 character with 1 uppercase, 1 lowercase, 1 digit and 1 special character please enter again");
			}catch(InvalidPasswordException e) {
				e.printStackTrace();
			}
		}while(!password.matches(regex_password));

		customer.setPassword(password);


		//Validating Confirm password

		do {
			try {

				System.out.println("Enter your Confirm password:");
				confirmPassword=in.next();
				if (!confirmPassword.matches(password))
					throw new InvalidPasswordException("Wrong password. Your password and confirm password should be same! please enter again");
			}catch(InvalidPasswordException e) {
				e.printStackTrace();
			}
		}while(!confirmPassword.matches(password));

		customer.setPassword(confirmPassword);


		Address address=getAddressDetails();

		customer.setAddress(address);
		return customer;

	}

	//Address details
	public Address getAddressDetails()
	{
		String addressLine1=null, city=null, state=null, zipcode=null;
		Address address=new Address();


		//Validating Address line 1
		do
		{
			System.out.println("Enter the Address Line 1");
			addressLine1=in.next();
			try {
				if(addressLine1==null || addressLine1==" ")
					throw new InvalidaddressLine1Exception("AddressLine1 should not be Empty or NUll! Please enter addressLine1 Again!");
			}
			catch(Exception e) {}

		}while(addressLine1==null || addressLine1==" ");
		address.setAddressLine1(addressLine1);

		//Address Line2
		System.out.println("Enter the Address Line 2");
		address.setAddressLine2(in.next());


		//Validating City
		do
		{
			System.out.println("Enter the city");
			city=in.next();
			try {
				if(city==null || city==" ")
					throw new InvalidaddressCityException("city should not be Empty or NUll! Please enter city Again!");
			}
			catch(Exception e) {}
		}while(city==null || city==" ");
		address.setCity(city);


		//Validating State
		do
		{
			System.out.println("Enter the State");
			state=in.next();
			try {
				if(state==null || state==" ")
					throw new InvalidaddressStateException("state should not be Empty or NUll! Please enter state Again!");
			}
			catch(Exception e) {}
		}while(state==null || state==" ");

		address.setState(state);


		//Validating PinCode
		do
		{
			System.out.println("Enter the Zipcode");
			zipcode=in.next();
			try {
				if(zipcode==null || zipcode==" ")
					throw new InvalidaddressZipCodeException("zipcode should not be Empty or NUll! Please enter zipcode Again!");
			}
			catch(Exception e) {}
		}while(zipcode==null || zipcode==" ");
		address.setZipCode(zipcode);


		return address;

	}

	//Implementing case 2 of main menu
	public Customer getCustomerEmailAndPassword() {
		//Validating Email ID
		String regex="^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@" 
				+ "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
		do {

			System.out.println("Enter your EmailID:");
			customer_emailId=in.next();
			try {
				if(!customer_emailId.matches(regex))
					throw new InvalidEmailIdException("Wrong Email Id! Please try Again!");
			} 
			catch (InvalidEmailIdException e) {
				System.out.println(e.getMessage());}
		}while(!customer_emailId.matches(regex));
		customer.setCustomer_emailId(customer_emailId);


		//Validating Password
		String regex_password= "^(?=.*[0-9])"
				+ "(?=.*[a-z])(?=.*[A-Z])"
				+ "(?=.*[@#$%^&+=])"
				+ "(?=\\S+$).{8,20}$";
		do {
			try {

				System.out.println("Enter your password:");
				password=in.next();
				if (!password.matches(regex_password))
					throw new InvalidPasswordException("Wrong password. Password must contains 8 character with 1 uppercase, 1 lowercase, 1 digit and 1 special character please enter again");
			}catch(InvalidPasswordException e) {
				e.printStackTrace();
			}
		}while(!password.matches(regex_password));
		customer.setPassword(password);

		return customer;
	}
	public void printMsg(String msg) {
		System.out.println(msg);

	}

	// Creating submenu of main menu case 2
	public int submenu()
	{
		System.out.println("1.Account Creation");
		System.out.println("2.List of account");
		System.out.println("3.Deposit Amount");
		System.out.println("4.Withdraw Amount");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Transaction  Summary");
		System.out.println("7.Log out");
		System.out.println("Enter the option from [1 to 7]");
		int choice1=  in.nextInt();
		return choice1;
	}
	//Implementing case 1 of sub menu getting the account details
	Account account=new Account();
	AccountType accounttype;
	public Account getAccountDetails() {

		Object accountType; String acctype = null;
		double openingbalance = 0; LocalDate openingDate;

		//Validating Account Type
		do {
			try {
				System.out.println("Enter your Account Type [SAVING OR CURRENT OR LOAN OR SALARY]");
				acctype=in.next();

				if(acctype.equals("SAVING"))
				{
					accounttype =AccountType.SAVING;

				}
				else if(acctype.equals("CURRENT"))
				{
					accounttype =AccountType.CURRENT;
				}
				else if(acctype.equals("LOAN"))
				{
					accounttype= AccountType.LOAN;

				}
				else if(acctype.equals("SALARY"))
				{
					accounttype= AccountType.SALARY;
				}
				if(!(acctype.equals("SAVING") || acctype.equals("CURRENT") || acctype.equals("LOAN") || acctype.equals("SALARY")))
					throw new InvalidaccountTypeException("Account type should matches as shown! Please enter Account Type Again!");
			}	
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}while(!(acctype.equals("SAVING") || acctype.equals("CURRENT") || acctype.equals("LOAN") || acctype.equals("SALARY")));
		account.setAccountType(accounttype);

		//Validating opening balance
		do {
			try
			{
				System.out.println("Enter the opening balance");
				openingbalance=in.nextDouble();
				if(!(openingbalance>=1000))
					throw new InvalidOpeniningBalanceException("The minimum balance for opening account should be 1000! Please try again ");
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}while(!(openingbalance>=1000));
		account.setOpeningBalance(openingbalance);

		double totalbal=account.getOpeningBalance();
		System.out.println("The account balance is "+totalbal);

		//Getting the opening date
		LocalDate lt = LocalDate.now();
		openingDate=lt;
		System.out.println("The opening date is:  "+openingDate);
		account.setOpeningDate(openingDate);



		//Description
		System.out.println("Please give your feedback");
		account.setDescription(in.next());

		return account;

	}
	//Case 2 of sub menu list all accounts
	public Account displayAllAccounts(List<Account> accounts) {
		if(accounts!=null)
		{
			System.out.println("AccountID \t Account_Type \t Opening_Balance \t Opening_Date \t Description");
			for(Account account: accounts)
			{
				System.out.println(account.getAccountId()+"\t"+account.getAccountType()+"\t"+account.getOpeningBalance()+"\t"+account.getOpeningDate()+"\t"+account.getDescription());
			}
			return account;
		}
		else {	

			System.out.println("There is no account available for you.Please create an account");
			return null;
		}

	}


	public void welcomeScreen(Customer customer1) {
		System.out.println("*********************");
		System.out.println("Welcome! " + customer1.getCustomerFirstName() +" " + customer1.getCustomerLastName() + ", You are authorized User!");
		System.out.println("*********************");


	}

	//Get account ID
	public int getAccountId() {

		int accountNumber=account.getAccountId();
		System.out.println("The Account number is : " +accountNumber);

		return accountNumber ;
	}

	//	//Deposit amount
	//	public Account balanceDeposit(Account account) {
	//		double  bal=0.0;
	//		double totalbal =0.0;// account.getOpeningBalance();
	//		System.out.println("Please enter amount to be deposited");
	//		bal=(in.nextDouble());
	//
	//		if(account!=null) {
	//
	//			int accountNumber=account.getAccountId();
	//			totalbal = account.getOpeningBalance()+bal;
	//			account.setOpeningBalance(account.getOpeningBalance()+bal);
	//			//totalbal+=bal;
	//		}
	//		else{
	//			System.out.println("sorry invalid credentials.Please try again!");
	//		}
	//		System.out.println("Rs "+bal+" is added to you wallet. Your current balance is" +totalbal);
	//
	//		return account;
	//	}

	//	//Withdraw amount
	//	@SuppressWarnings("unused")
	//	public Account balWithdraw(Account account) {
	//		double  bal=0;
	//		double totalbal = account.getOpeningBalance();
	//		System.out.println("Please enter amount to be withdrawn");
	//		bal=(in.nextDouble());
	//
	//		if(account!=null) {
	//			int accountNumber=account.getAccountId();
	//			account.setOpeningBalance(account.getOpeningBalance()-bal);
	//			totalbal-=bal;
	//		}
	//		else {
	//			System.out.println("sorry invalid credentials.Please try again!");
	//		}
	//		System.out.println("Rs "+bal+" is withdrwan to you wallet. Your current balance is"+totalbal);
	//
	//		return account;
	//	}
	//

	public Account getAccountvalidation() {
		int accId=0;
		do
		{
			try
			{
				System.out.println("Enter the account number");
				accId=in.nextInt();
				if(accId==0)
					throw new InvalidAccountIdException("The entered account ID is invalid! Please try again");
			}
			catch(Exception e)
			{

			}

		}while(accId==0);

		account.setAccountId(accId); 
		return account;
	}
	public void printAccounts(List<Account> accounts) {
		int i=1;
		for(Account account:accounts) {
			System.out.println(i + " " + account);
			i++;
		}
	}
	public void printAccounts(Account acc) {
		System.out.println(acc);

	}

	//List of account and debit and credit operation
	public int listAllAccount(List<Account> accounts) {

		for(Account account:accounts)
		{
			System.out.println("AccountID \t AccountType \t Balance");
			System.out.println(account.getAccountId() +"\t" + account.getAccountType() +"\t"+account.getOpeningBalance());
		}
		System.out.println("Enter the account ID");
		int accNo=in.nextInt();
		return accNo;
	}
	public double getDepositAmount() {
		System.out.println("Enter the amout to deposit");
		return in.nextDouble();
	}
	public double getWithdrawAmount() {
		System.out.println("Enter the amout to be debited");
		return in.nextDouble();
	}

	//Transaction summary
	public LocalDate getFromDate() {
		System.out.println("Enter the from date of transaction summary need to be displayed");

		String startdate=in.next();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate transdate=LocalDate.parse(startdate,formatter);	
		return transdate;

	}

	public LocalDate gettoDate() {
		System.out.println("Enter the to date of transaaction summary need to be displayed");

		String enddate=in.next();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate transdate=LocalDate.parse(enddate,formatter);

		return transdate;

	}

	public void printTransactions(List<Transaction> trans) {
		if(trans!=null)
		{
			System.out.println("TransactionID \t Transaction_Type \t Transaction_date_time \t description \t fromAccount \t toAccount \t amount");
			for(Transaction transaction: trans)
			{
				System.out.println(transaction.getTransactionId()+"\t"+transaction.getTransactionType()+"\t"+transaction.getTransactionDateTime()
				+"\t"+transaction.getDescription()+"\t"+transaction.getFromAccount()+"\t"+transaction.getToAccount()+"\t"+transaction.getAmount());
			}
		
		}
		else {	

			System.out.println("There is no transaction available for you from this date");
		}
	}
	//Fund transfer
	public int listAllAccounts(List<Account> accounts) {

		System.out.println("Choose the account number");

		for(Account account:accounts) 
			System.out.println(account.getAccountId() + "\t"
					+account.getAccountType() + "\t"
					+ account.getBalance());

		System.out.println("Enter your Account No.");
		int accNo = in.nextInt();
		System.out.println("your Enterd Account No. is: "+ accNo);

		return accNo;
	}
	public double getAmount(String str) {
		System.out.println("Enter funds to transfer :");
		double amount =in.nextDouble();
		System.out.println("your Enterd Ammount is: "+ amount);
		return amount;
	}


}