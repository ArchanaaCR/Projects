package org.cap.WalletApplication.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import org.cap.WalletApplication.UserInterface.UserInterface;
import org.cap.WalletApplication.dao.CustomerdbdaoImp;
import org.cap.WalletApplication.exceptionhandling.DataInsertionException;
import org.cap.WalletApplication.exceptionhandling.InvalidAccountNumberException;
import org.cap.WalletApplication.model.Account;
import org.cap.WalletApplication.model.Address;
import org.cap.WalletApplication.model.Customer;
import org.cap.WalletApplication.model.Transaction;
import org.cap.WalletApplication.service.CustomerServiceImp;
import org.cap.WalletApplication.service.ICustomerService;

public class BootClass {
	public static void main(String args[]) 
	{
		Scanner in=new Scanner(System.in);
		UserInterface userinterface=new UserInterface();
		ICustomerService customerservice=new CustomerServiceImp();
		CustomerdbdaoImp customerdbdao=new CustomerdbdaoImp();
		//int choice=userinterface.mainmenu();
		String mychoice=null;
		do {
			int choice=userinterface.mainmenu();
			switch(choice)
			{
			case 1:
			{	
				Customer customer=userinterface.getCustomerDetails();
				boolean flag=false;
				try {
					flag = customerservice.addCustomer(customer);
				} catch (DataInsertionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(flag)
					userinterface.printMsg("Your login had been completed Successfully!");		
				break;

			}
			case 2:
			{
				Customer customervalidation=userinterface.getCustomerEmailAndPassword();
				Customer customer=customerservice.loginCustomer(customervalidation.getCustomer_emailId(), customervalidation.getpassword());
				if(customer!=null) {
					System.out.flush();
					userinterface.welcomeScreen(customer);
					String myChoice_trans=null;

					do {
						int choice1=userinterface.submenu();
						switch(choice1)
						{
						case 1:
						{
							Account account=userinterface.getAccountDetails();

							Account account1=customerservice.createAccount(account, customer);
							List<Account> acc=new ArrayList<Account>();
							acc.add(account1);
							if(acc!=null)
							{
								userinterface.printMsg("Account Created Successfully! ");//Your Account No.: "+account.getAccountId());
								System.out.println(acc);
							}
							else
								System.out.println("Your account has not been created! Please try again");
							break;
						}
						case 2:
						{	
							List<Account> accounts=customerservice.getAllAccountByCustomerID(customer.getCustomerID(),"fromaccount");
							Account account=userinterface.displayAllAccounts(accounts);

							break;
						}

						case 3:
						{
							Account account = null;
							List<Account> accounts=customerservice.getAllAccountByCustomerID(customer.getCustomerID(),"fromaccount");
							int accNo=userinterface.listAllAccount(accounts);
							account=customerservice.getAccountByAccountNo(accNo);
							double amount=userinterface.getDepositAmount();

							try {
								account = customerservice.depositOrWithdrawAmount(account, amount,"credit");
							} catch (InvalidAccountNumberException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(account!=null)
							{
								userinterface.printMsg("The amount had been credited successfully!");
								System.out.println(account);
							}

							break;

						}
						case 4:
						{
							Account account = null;
							List<Account> accounts=customerservice.getAllAccountByCustomerID(customer.getCustomerID(),"fromaccount");
							int accNo=userinterface.listAllAccount(accounts);
							account=customerservice.getAccountByAccountNo(accNo);
							double amount=userinterface.getWithdrawAmount();

							try {
								account = customerservice.depositOrWithdrawAmount(account, amount,"debit");
							} catch (InvalidAccountNumberException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(account!=null)
							{
								userinterface.printMsg("The amount had been debited successfully!");
								System.out.println(account);
							}

							break;

						}
						case 5:
						{	
							Account fromaccount; Account toaccount;
							do {				
								List<Account> accounts=customerservice.getAllAccountByCustomerID(customer.getCustomerID(),"fromaccount");
								int accNo=userinterface.listAllAccount(accounts);
								fromaccount = customerservice.getAccountByAccountNo(accNo);
								if(fromaccount==null)
									userinterface.printMsg("Incorrect Account no! Please enter again.");
							}while(fromaccount==null);

							do {
								List<Account> accounts = customerservice.getAllAccountByCustomerID(customer.getCustomerID(),"toaccount");
								int accNo=userinterface.listAllAccount(accounts);
								toaccount = customerservice.getAccountByAccountNo(accNo);
								if(toaccount==null)
									userinterface.printMsg("Incorrect Account no! Please enter again.");
							}while(toaccount==null);

							double amount = userinterface.getAmount("Transfer");

							if(fromaccount.getOpeningBalance()<amount) 
								userinterface.printMsg("Insufficient Balance!");
							else {
								try {
									fromaccount = customerservice.depositOrWithdrawAmount(fromaccount,amount,"debit");
									toaccount = customerservice.depositOrWithdrawAmount(toaccount,amount,"credit");
								} catch (InvalidAccountNumberException e) {
									e.printStackTrace();
								}
								if(fromaccount!=null && toaccount!=null) {
									userinterface.printMsg("Amount withdrawn from Account successfully!");
								}
							}

							break;
						}
						case 6:
						{

							LocalDate fromdate=userinterface.getFromDate();
							LocalDate toDate=userinterface.gettoDate();
							
							List<Transaction> trans= customerservice.getTransactionSummary(customer.getCustomerID(), fromdate,toDate );
							System.out.println(trans);
							userinterface.printTransactions(trans);

							break;
						}
						case 7:
						{
							System.out.println("Your Account had been logged  out successfully");
							System.exit(0);
						}
						default:
						{
							throw new IllegalArgumentException("Unexpected value: " + choice1);
						}

						}
						System.out.println("Do you wish to Continue?[Y/N]");
						mychoice =in.next();
					}while(mychoice.equalsIgnoreCase("Y"));

				}
				else {
					System.out.println("Invalid Login! Try Again!");
				}
				break;
			}
			case 3:
			{
				System.out.println("Your Account had been signed out successfully");
				System.exit(0);
			}
			default:
			{
				System.out.println("Enter the correct option");
			}
			}
			System.out.println("Do you wish to Continue?[Y/N]");
			mychoice =in.next();
		}while(mychoice.equalsIgnoreCase("Y"));

	}
	public static void clearScreen() {
		final String osname=System.getProperty("os.name");
		if(osname.contains("windows"))
			try {
				Runtime.getRuntime().exec("cls");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}
}
