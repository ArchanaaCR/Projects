/*package org.cap.WalletApplication.dao;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.WalletApplication.exceptionhandling.InvalidAccountNumberException;
import org.cap.WalletApplication.model.Account;
import org.cap.WalletApplication.model.Address;
import org.cap.WalletApplication.model.Customer;
import org.cap.WalletApplication.model.Transaction;

public class CustomerCreationImp implements Icustomercreation {
	
	private static AtomicInteger addressId=new AtomicInteger(3452);
	private static AtomicInteger customerId=new AtomicInteger(1234);
	private static AtomicInteger accountId=new AtomicInteger(123);
	
	private static List<Customer> customers=dummyCustomerDB();
	private static List<Account> accounts=dummyAccountDB();
	private static List<Address> address1=dummyAddressDB();
	@Override
	public boolean addCustomer(Customer customer) {
		customer.setCustomerID(customerId.getAndIncrement());
		customer.getAddress().setAddressId(addressId.getAndIncrement());		
		customers.add(customer);
		
		System.out.println(customers);
		return customers.add(customer);
		
	}
	


	@SuppressWarnings("unchecked")
	public static List<Customer> dummyCustomerDB() {
		
		
		List<Customer> customers=new ArrayList<Customer>();
		
//		Customer customer=new Customer(customerId.getAndIncrement(), customerFirstName.getCustomerFirstName(),customer.getCustomerLastName(),customer.getCustomer_emailId(),customer.getCustomer_number(),customer.getAddress(),customer.getAccount(),customer.getpassword());
//		List<Customer> customer1=dummyCustomerDB();
//		((List<Customer>) customer).add((Customer) customer1);		
		
		return customers;
	}

	@Override
	public boolean addAddress(Address address) {
		address.setAddressId(address.getAddressId());
		address.setAddressLine1(address.getAddressLine1());
		address.setAddressLine2(address.getAddressLine2());
		address.setCity(address.getCity());
		address.setState(address.getState());
		address.setZipCode(address.getZipCode());
		
		address1.add(address);
		
		System.out.println(address);
		
		return false;
	}
	
		

	private static List<Address> dummyAddressDB() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Customer loginCustomer(String customer_emailId, String password) {

		for (Customer customer:customers)
		{
			if(customer.getCustomer_emailId().equals(customer_emailId) && customer.getpassword().equals(password))
				return customer;
		}
		return null;
	}

	public boolean addAccount(Account account) {
		
		account.setAccountId(accountId.getAndIncrement());
		accounts.add(account);
		System.out.println(accounts);
		return accounts.add(account);
		
	}


	public static List<Account> dummyAccountDB() {
		
		List<Account> accounts=new ArrayList<Account>();
		return accounts;
	}

	public Customer findCustomer(int customerId) {
		for(Customer customer:customers) {
			if(customer.getCustomerID()==customerId)
				return customer;
		}
		
		return null;
	}
	
public Account createAccount(Account account, Customer customer) {
		
		if(findCustomer(customer.getCustomerID())!=null){
			account.setAccountId(accountId.getAndIncrement());
			customer.getAccount().add(account);
			accounts.add(account);
			return account;
		}
		
		return null;
	}
//	@Override
//	public Account createAccount(Account account, Customer customer) {
//		for(Customer customer1:dummyCustomerDB()) {
//			if(customer1.getCustomerID()==customer.getCustomerID()) {
//				account.setAccountId(accountId.getAndIncrement());
//				customer.getAccount().add(account);
//				accounts.add(account);
//				return account;
//			}
//		
//		}
//		
//		return null;
//	}
	
	public Account findAccount(int accountNo) {
		for(Account account:accounts) {
			if(account.getAccountId()==accountNo)
				return account;
		}
		
		return null;
	}



	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return dummyCustomerDB();
	}



	@Override
	public Account loginCustomer(int accountId) {
		for (Account account:accounts)
		{
			if(account.getAccountId()==accountId)
				return account;
		}
		return null;
	}



	@Override
	public boolean addAddress(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public List<Account> getAllAccountByCustomerID(int customerID, String type) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Account depositOrWithdrawAmount(Account account, double amount, String type)
			throws InvalidAccountNumberException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Transaction getTransactionSummary(int customerID, LocalDate fromDate, LocalDate toDate) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Account funtransfer(int fromAcc, int toAcc, double amount) {
		// TODO Auto-generated method stub
		return null;
	}



	


	
	
}*/
