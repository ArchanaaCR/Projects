package org.cap.WalletApplication.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;
import org.cap.WalletApplication.UserInterface.UserInterface;
import org.cap.WalletApplication.exceptionhandling.DataInsertionException;
import org.cap.WalletApplication.exceptionhandling.InvalidAccountNumberException;
import org.cap.WalletApplication.model.Account;
import org.cap.WalletApplication.model.AccountType;
import org.cap.WalletApplication.model.Address;
import org.cap.WalletApplication.model.Customer;
import org.cap.WalletApplication.model.Transaction;
import org.cap.WalletApplication.model.TransactionType;

public class CustomerdbdaoImp implements Icustomercreation  {
	public static Scanner in=new Scanner(System.in);


	UserInterface userinterface=new UserInterface();

	public boolean addCustomer(Customer customer) throws DataInsertionException {
		int customerID=0;
		Connection connection=null;
		try {
			String insert_cd="insert into Customer (customerFirstName,customerLastName,"
					+ "customer_number,customer_emailId,password) values(?,?,?,?,?);";
			PreparedStatement preparedstatement=getMySQlConnect().prepareStatement(insert_cd,  PreparedStatement.RETURN_GENERATED_KEYS);
			Customer customer1=customer;

			preparedstatement.setString(1, customer1.getCustomerFirstName());
			preparedstatement.setString(2, customer1.getCustomerLastName());	
			preparedstatement.setString(3, customer1.getCustomer_number());
			preparedstatement.setString(4, customer1.getCustomer_emailId());
			preparedstatement.setString(5, customer1.getpassword());

			int count=preparedstatement.executeUpdate();
			ResultSet resultSet= preparedstatement.getGeneratedKeys();
			if(resultSet.next())
				customerID=resultSet.getInt(1);
			customer.setCustomerID(customerID);
			if(count>0) {

				if(addAddress(customer))
					return true;
				else
					throw new DataInsertionException("Address Insertion error!!");
			}else
				throw new DataInsertionException("Address Insertion error!!");
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public boolean addAddress(Customer customer) {
		try {
			String insert_ad="insert into address (addressLine1,addressLine2,"
					+ "city,state,zipCode,customerID) values(?,?,?,?,?,?);";
			PreparedStatement statement=getMySQlConnect().prepareStatement(insert_ad);


			statement.setString(1, customer.getAddress().getAddressLine1());
			statement.setString(2, customer.getAddress().getAddressLine2());
			statement.setString(3, customer.getAddress().getCity());
			statement.setString(4, customer.getAddress().getState());
			statement.setString(5, customer.getAddress().getZipCode());
			statement.setInt(6, customer.getCustomerID());

			int count=statement.executeUpdate();
			if(count > 0)
				return true;
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return false;
	}


	public Customer loginCustomer(String customer_emailId, String password) {
		String sql="select * from customer where customer_emailId=? and password=? ";
		Customer customer=new Customer();
		try {
			PreparedStatement preparedStatement=getMySQlConnect().prepareStatement(sql);
			preparedStatement.setString(1, customer_emailId);
			preparedStatement.setString(2, password);
			ResultSet resultSet= preparedStatement.executeQuery();

			if(resultSet.next()) {

				customer.setCustomerID(resultSet.getInt("customerID"));
				customer.setCustomerFirstName(resultSet.getString("customerFirstName"));
				customer.setCustomerLastName(resultSet.getString("customerLastName"));
				customer.setCustomer_emailId(resultSet.getString("customer_emailId"));
				customer.setCustomer_number(resultSet.getString("customer_number"));
				customer.setPassword(resultSet.getString("password"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return customer;
	}

	@Override
	public Account createAccount(Account account, Customer customer) {
		int accountNumber=0;

		try {
			String sql="insert into Account(accountType,openingDate,openingBalance,description,customerID) values (?,?,?,?,?)";
			PreparedStatement preparedStatement=getMySQlConnect().prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);

			preparedStatement.setString(1, account.getAccountType().name());
			preparedStatement.setDate(2, Date.valueOf( account.getOpeningDate()));
			preparedStatement.setBigDecimal(3, BigDecimal.valueOf( account.getOpeningBalance()));
			preparedStatement.setString(4, account.getDescription());
			preparedStatement.setInt(5, customer.getCustomerID());
			int count=preparedStatement.executeUpdate();
			ResultSet resultset=preparedStatement.getGeneratedKeys();
			if(resultset.next()) {
				resultset.getInt(1);
			}
			if(count>0)
				account.setAccountId(accountNumber);
			return account;
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<Account> getAllAccountByCustomerID(int customerID, String type) {
		List<Account> accounts=new ArrayList<>();
		String sql=null;
		try
		{
			if(type.equalsIgnoreCase("fromaccount"))
				sql="select * from account where customerId=?;";
			else
				sql="select * from account where customerId !=?;";
			PreparedStatement preparedStatement=getMySQlConnect().prepareStatement(sql);
			preparedStatement.setInt(1, customerID);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				Account account=new Account();
				account.setAccountId(rs.getInt("accountID"));
				account.setAccountType(findAccountType(rs.getString("accountType")));
				account.setOpeningBalance(rs.getBigDecimal("openingBalance").doubleValue());
				account.setOpeningDate(rs.getDate("openingDate").toLocalDate());
				account.setDescription(rs.getString("description"));
				accounts.add(account);
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}

		return accounts;
	}
	private AccountType findAccountType(String type)
	{
		if(type.equals("SAVING"))
		{
			return AccountType.SAVING;

		}
		else if(type.equals("CURRENT"))
		{
			return AccountType.CURRENT;

		}
		else if(type.equals("LOAN"))
		{
			return AccountType.LOAN;

		}
		else if(type.equals("SALARY"))
		{
			return AccountType.SALARY;
		}
		else 
			return null;
	}




	@Override
	public Account depositOrWithdrawAmount(Account account, double amount, String type) throws InvalidAccountNumberException {
		//Account account1=findAccount(account); 
		String sql=null;
		if(account!=null) {
			try
			{
				if(type.equalsIgnoreCase("credit"))
				{
					sql="update account set openingBalance=openingBalance + ? where accountId=?";
				}
				else
				{
					sql="update account set openingBalance=openingBalance - ? where accountId=?";
				}
				PreparedStatement preparedStatement=getMySQlConnect().prepareStatement(sql);
				preparedStatement.setDouble(1, amount);
				preparedStatement.setInt(2, account.getAccountId());
				int count=preparedStatement.executeUpdate();
				if(count>0)
				{
					if(type.equalsIgnoreCase("credit"))
						account.setOpeningBalance(account.getOpeningBalance()+amount);
					else
						account.setOpeningBalance(account.getOpeningBalance()-amount);
					//add transaction into table
					String sql1="insert into transaction(transactionType,transactionDateTime,description,fromAccount,amount) "
							+ "values(?,?,?,?,?)";
					PreparedStatement preparedStatement2=getMySQlConnect().prepareStatement(sql1);
					preparedStatement2.setString(1, type);
					preparedStatement2.setObject(2, LocalDateTime.now());
					if(type.equalsIgnoreCase("credit"))
						preparedStatement2.setString(3, "Amount Deposited");
					else
						preparedStatement2.setString(3, "Amount Withdrawn");
					preparedStatement2.setInt(4, account.getAccountId());
					preparedStatement2.setBigDecimal(5, BigDecimal.valueOf(amount));
					int count1=preparedStatement2.executeUpdate();
					if(count1>0)
						return account;
				}
			}catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		else
			throw new InvalidAccountNumberException("Sorry Invalid account number!");
		return null;
	}
	public Account findAccount(int accountId)
	{
		Account account=null;
		try
		{
			String sql="select * from account where accountId=?";
			PreparedStatement preparedStatement=getMySQlConnect().prepareStatement(sql);
			preparedStatement.setInt(1, accountId);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				account=new Account();
				account.setAccountId(rs.getInt("accountId"));
				account.setAccountType(findAccountType(rs.getString("accountType")));
				account.setOpeningBalance(rs.getBigDecimal("openingBalance").doubleValue());
				account.setOpeningDate(rs.getDate("openingDate").toLocalDate());
				account.setDescription(rs.getString("description"));

			}

		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return account;

	}
	
	// Transaction summary
	public List<Transaction> getTransactionSummary(int customerID,LocalDate fromDate, LocalDate toDate) 
	{
		LocalDate date = fromDate,date1 = toDate;
		List<Transaction> transactions=new ArrayList<>();
		try {
			String sql = "select t.transactionId,t.transactionType,t.transactionDateTime,t.description,t.fromAccount,"
					+ "t.toAccount,t.amount from transaction t,account a "
					+ "where t.fromaccount =  a.accountId and a.customerId =?;";
			
	
			
//			String sql="select t.transactionId,t.transactionType,t.transactionDateTime,t.description,t.fromAccount,"
//					+ "t.toAccount,t.amount from transaction t,account a "
//					+ "where t.fromaccount =  a.accountId and a.customerId =?;";
			
			PreparedStatement preparedStatement=getMySQlConnect().prepareStatement(sql);
			preparedStatement.setInt(1, customerID);
//			preparedStatement.setObject(2, date);
//			preparedStatement.setObject(3, date1);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				Transaction transaction=new Transaction();
				transaction.setTransactionId(rs.getInt("transactionId"));
				transaction.setTransactionType(findTransactionType(rs.getString("transactionType")));
				transaction.setTransactionDateTime(rs.getTimestamp(3).toLocalDateTime());
				transaction.setDescription(rs.getString("description"));
				transaction.setFromAccount(findAccount(rs.getInt("fromAccount")));
				transaction.setToAccount(findAccount(rs.getInt("toAccount")));
				transaction.setAmount(rs.getBigDecimal("amount").doubleValue());
				transactions.add(transaction);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return transactions;

	}
	private TransactionType findTransactionType(String type)
	{
		if(type.equalsIgnoreCase("DEBIT"))
		{
			return TransactionType.DEBIT;
		}
		else if(type.equalsIgnoreCase("CREDIT"))
		{
			return TransactionType.CREDIT;
		}
		else
			return null;
	}

	//Fund Transafer
	@Override
	public Account funtransfer(int fromAcc, int toAcc, double amount) {
		Account account=findAccount(fromAcc);
		String sql="update account set openingBalance=openingBalance - ? where accountId=?";
		PreparedStatement preparedStatement;
		try {
			preparedStatement = getMySQlConnect().prepareStatement(sql);
			preparedStatement.setDouble(1, amount);
			preparedStatement.setInt(2, fromAcc);
			int count=preparedStatement.executeUpdate();
			if(count>0)
			{
				account.setOpeningBalance(account.getOpeningBalance()-amount);
				//add transaction into table
				String sql1="insert into transaction(transactionType,transactionDateTime,description,fromAccount,amount) "
						+ "values(?,?,?,?,?)";
				PreparedStatement preparedStatement2=getMySQlConnect().prepareStatement(sql1);
				preparedStatement2.setString(1, "Debit");
				preparedStatement2.setObject(2, LocalDateTime.now());
				preparedStatement2.setString(3, "Amount Debited");
				preparedStatement2.setInt(4, fromAcc);
				preparedStatement2.setBigDecimal(5, BigDecimal.valueOf(amount));
				int count1=preparedStatement2.executeUpdate();
				if(count1>0)
					return account;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		sql="update account set openingBalance=openingBalance + ? where accountId=?";

		try {
			preparedStatement = getMySQlConnect().prepareStatement(sql);
			preparedStatement.setDouble(1, amount);
			preparedStatement.setInt(2, toAcc);
			int count=preparedStatement.executeUpdate();
			if(count>0)
			{

				account.setOpeningBalance(account.getOpeningBalance()+amount);
				//add transaction into table
				String sql1="insert into transaction(transactionType,transactionDateTime,description,fromAccount,amount) "
						+ "values(?,?,?,?,?)";
				PreparedStatement preparedStatement2=getMySQlConnect().prepareStatement(sql1);
				preparedStatement2.setString(1, "Credit");
				preparedStatement2.setObject(2, LocalDateTime.now());
				preparedStatement2.setString(3, "Amount Credited");
				preparedStatement2.setInt(4, toAcc);
				preparedStatement2.setBigDecimal(5, BigDecimal.valueOf(amount));
				int count1=preparedStatement2.executeUpdate();
				if(count1>0)
					return account;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



		return null;
	}


	public Connection getMySQlConnect()
	{

		Connection connection=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager
					.getConnection("jdbc:mysql://localhost:3306/ewallet1", "root", "123456");
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return connection;
	}

	

}

