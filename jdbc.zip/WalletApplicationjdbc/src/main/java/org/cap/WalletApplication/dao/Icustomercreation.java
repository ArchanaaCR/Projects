package org.cap.WalletApplication.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.cap.WalletApplication.exceptionhandling.DataInsertionException;
import org.cap.WalletApplication.exceptionhandling.InvalidAccountNumberException;
import org.cap.WalletApplication.model.Account;
import org.cap.WalletApplication.model.Address;
import org.cap.WalletApplication.model.Customer;
import org.cap.WalletApplication.model.Transaction;

public interface Icustomercreation {
	public boolean addCustomer(Customer customer) throws DataInsertionException;
	public boolean addAddress(Customer customer);
	public Customer loginCustomer(String customer_emailId, String password);
	public Account createAccount(Account account, Customer customer);
	public Account findAccount(int accountId);
	public List<Account> getAllAccountByCustomerID(int customerID, String type);
	public Account depositOrWithdrawAmount(Account account, double amount, String type) throws InvalidAccountNumberException;
	public List<Transaction> getTransactionSummary(int customerID,LocalDate fromDate, LocalDate toDate);
	public Account funtransfer(int fromAcc, int toAcc, double amount);
	
}
