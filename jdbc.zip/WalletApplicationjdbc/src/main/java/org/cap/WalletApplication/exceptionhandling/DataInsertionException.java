package org.cap.WalletApplication.exceptionhandling;

public class DataInsertionException extends Exception {
	public  DataInsertionException(String msg)
	{
		super(msg);
	}
}
