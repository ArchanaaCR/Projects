package org.cap.WalletApplication.exceptionhandling;

public class InvalidAccountIdException extends Exception {
	public InvalidAccountIdException(String msg)
	{
		super(msg);
	}

}
