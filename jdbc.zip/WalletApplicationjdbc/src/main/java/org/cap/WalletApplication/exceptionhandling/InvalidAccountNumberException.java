package org.cap.WalletApplication.exceptionhandling;

public class InvalidAccountNumberException extends Exception {
	public InvalidAccountNumberException(String msg)
	{
		super(msg);
	}
}
