package org.cap.WalletApplication.exceptionhandling;

public class InvalidContactNumberException extends Exception {
	public InvalidContactNumberException(String msg)
	{
		super(msg);
	}

}
