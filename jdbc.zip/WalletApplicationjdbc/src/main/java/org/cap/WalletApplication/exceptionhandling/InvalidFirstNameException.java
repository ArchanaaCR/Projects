package org.cap.WalletApplication.exceptionhandling;


public class InvalidFirstNameException extends Exception{

	public InvalidFirstNameException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	
	
	
}
