package org.cap.WalletApplication.exceptionhandling;

public class InvalidOpeniningBalanceException extends Exception {
	public InvalidOpeniningBalanceException(String msg)
	{
		super(msg);
	}
}
