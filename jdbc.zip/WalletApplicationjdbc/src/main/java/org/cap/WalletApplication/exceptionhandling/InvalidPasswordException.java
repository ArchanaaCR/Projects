package org.cap.WalletApplication.exceptionhandling;

public class InvalidPasswordException extends Exception{

	public InvalidPasswordException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
}
	
	
