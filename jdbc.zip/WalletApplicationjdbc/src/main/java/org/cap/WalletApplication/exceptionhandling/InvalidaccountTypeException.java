package org.cap.WalletApplication.exceptionhandling;

public class InvalidaccountTypeException extends Exception {
	public InvalidaccountTypeException(String msg) {
		super(msg);
}
}
