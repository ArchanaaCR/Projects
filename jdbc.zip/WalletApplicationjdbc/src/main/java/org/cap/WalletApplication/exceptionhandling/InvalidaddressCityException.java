package org.cap.WalletApplication.exceptionhandling;

public class InvalidaddressCityException extends Exception {
	public InvalidaddressCityException(String msg)
	{
		super(msg);
	}

}
