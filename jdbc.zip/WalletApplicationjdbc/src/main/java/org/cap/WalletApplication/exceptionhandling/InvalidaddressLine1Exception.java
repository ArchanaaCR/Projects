package org.cap.WalletApplication.exceptionhandling;

public class InvalidaddressLine1Exception extends Exception {
	public InvalidaddressLine1Exception(String msg)
	{
		super(msg);
	}
}
