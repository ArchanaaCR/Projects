package org.cap.WalletApplication.exceptionhandling;

public class InvalidaddressLine2Exception extends Exception {
	public InvalidaddressLine2Exception(String msg) {
		super(msg);
	}

}
