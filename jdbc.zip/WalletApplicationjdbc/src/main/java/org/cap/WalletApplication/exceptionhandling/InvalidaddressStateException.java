package org.cap.WalletApplication.exceptionhandling;

public class InvalidaddressStateException extends Exception {
	public InvalidaddressStateException(String msg)
	{
		super(msg);
	
	}
}
