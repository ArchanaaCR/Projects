package org.cap.WalletApplication.exceptionhandling;

public class InvalidaddressZipCodeException extends Exception {
	public InvalidaddressZipCodeException(String msg)
	{
		super(msg);
	}

}
