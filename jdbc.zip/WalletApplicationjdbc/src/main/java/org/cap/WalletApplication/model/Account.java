package org.cap.WalletApplication.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Account {
	private int accountId;
	private AccountType accountType;
	private double openingBalance;
	private LocalDate openingDate;
	private String description;
	private List<Transaction> transaction=new ArrayList<Transaction>();
	private String Transaction;
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public AccountType getAccountType() {
		return accountType;
	}
	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}
	public double getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}
	public LocalDate getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Transaction> getTransaction1() {
		return transaction;
	}
	public void setTransaction(List<Transaction> transaction) {
		this.transaction = transaction;
	}
	public String getTransaction() {
		return Transaction;
	}
	public void setTransaction(String transaction) {
		Transaction = transaction;
	}
	
	
	public Account(int accountId, AccountType accountType, double openingBalance, LocalDate openingDate,
			String description) {
		super();
		this.accountId = accountId;
		this.accountType = accountType;
		this.openingBalance = openingBalance;
		this.openingDate = openingDate;
		this.description = description;
	}
	public Account(int accountId, AccountType accountType, double openingBalance, LocalDate openingDate,
			String description, List<org.cap.WalletApplication.model.Transaction> transaction, String transaction2) {
		super();
		this.accountId = accountId;
		this.accountType = accountType;
		this.openingBalance = openingBalance;
		this.openingDate = openingDate;
		this.description = description;
		this.transaction = transaction;
		Transaction = transaction2;
	}
	public Account() {
		super();
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountType=" + accountType + ", openingBalance=" + openingBalance
				+ ", openingDate=" + openingDate + ", description=" + description + ", transaction=" + transaction
				+ ", Transaction=" + Transaction + "]";
	}
	double balance;
	public void setBalance(double d) {
		
	balance=d;
	}
	public double getBalance() {
		// TODO Auto-generated method stub
		return balance;
	}
	
	
}
