package org.cap.WalletApplication.model;

public enum AccountType {
	SAVING, CURRENT, LOAN, SALARY;

	 
}
