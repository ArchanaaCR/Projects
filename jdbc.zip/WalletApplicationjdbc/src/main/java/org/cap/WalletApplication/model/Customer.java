package org.cap.WalletApplication.model;

import java.util.ArrayList;
import java.util.List;

//import org.cap.WalletApplication.model.Address;

public class Customer {
	private int customerID;
	private String customerFirstName;
	private String customerLastName;
	private String customer_number;
	private String customer_emailId;
	private String password;
	private String confirmPassword;
	private Address address;
	private List<Account> account=new ArrayList<Account>();
	
	public Customer(int customerID, String customerFirstName, String customerLastName, String customer_number,
			String customer_emailId, String password, String confirmPassword, Address address, List<Account> account) {
		super();
		this.customerID = customerID;
		this.customerFirstName = customerFirstName;
		this.customerLastName = customerLastName;
		this.customer_number = customer_number;
		this.customer_emailId = customer_emailId;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.address = address;
		this.account = account;
	}
	public Customer() {
		super();
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCustomerFirstName() {
		return customerFirstName;
	}
	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}
	public String getCustomerLastName() {
		return customerLastName;
	}
	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}
	public String getCustomer_emailId() {
		return customer_emailId;
	}
	public void setCustomer_emailId(String customer_emailId) {
		this.customer_emailId = customer_emailId;
	}
	public String getCustomer_number() {
		return customer_number;
	}
	public void setCustomer_number(String customer_number) {
		this.customer_number = customer_number;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getpassword() {
		return password;
	}
	public void setPassword(String password)
	{
		this.password=password;
	}
	public List<Account> getAccount() {
		return account;
	}
	public void setAccount(List<Account> account) {
		this.account = account;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", customerFirstName=" + customerFirstName + ", customerLastName="
				+ customerLastName + ", customer_number=" + customer_number + ", customer_emailId=" + customer_emailId
				+ ", password=" + password + ", confirmPassword=" + confirmPassword + ", address=" + address
				+ ", account=" + account + "]";
	}
	
	
}
