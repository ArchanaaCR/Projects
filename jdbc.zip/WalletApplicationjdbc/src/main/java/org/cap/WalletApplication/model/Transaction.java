package org.cap.WalletApplication.model;

import java.time.LocalDateTime;

public class Transaction {
	private int transactionId;
	private TransactionType transactionType;
	private LocalDateTime transactionDateTime=LocalDateTime.now();
	private String description;
	private double amount;
	private Account fromAccount;
	//private int fromAccount;
	private Account toAccount;
	//private int toAccount;
	
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public LocalDateTime getTransactionDateTime() {
		return transactionDateTime;
	}
	public void setTransactionDateTime(LocalDateTime transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	public TransactionType getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
//	public Account getFromAccount() {
//		return fromAccount;
//	}
//	public void setFromAccount(Account fromAccount) {
//		this.fromAccount = fromAccount;
//	}
//	public Account getToAccount() {
//		return toAccount;
//	}
//	public void setToAccount(Account toAccount) {
//		this.toAccount = toAccount;
//	}
	public Account getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(Account account) {
		this.fromAccount = account;
	}
	public Account getToAccount() {
		return toAccount;
	}
	public void setToAccount(Account toAccount) {
		this.toAccount = toAccount;
	}
	public Transaction() {
		super();
	}
	
	
	public Transaction(int transactionId, TransactionType transactionType, LocalDateTime transactionDateTime,
			String description, double amount) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDateTime = transactionDateTime;
		this.description = description;
		this.amount = amount;
	}
	public Transaction(int transactionId, LocalDateTime transactionDateTime, TransactionType transactionType,
			String description, Account fromAccount, Account toAccount) {
		super();
		this.transactionId = transactionId;
		this.transactionDateTime = transactionDateTime;
		this.transactionType = transactionType;
		this.description = description;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
	}
	
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", transactionDateTime=" + transactionDateTime + ", description=" + description + ", amount=" + amount
				+ ", fromAccount=" + fromAccount + ", toAccount=" + toAccount + "]";
	}
	
	

}
