package org.cap.WalletApplication.model;

public enum TransactionType {
	DEBIT, CREDIT;
}
