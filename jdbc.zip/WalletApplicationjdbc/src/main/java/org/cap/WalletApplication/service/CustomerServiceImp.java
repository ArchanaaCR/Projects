package org.cap.WalletApplication.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import org.cap.WalletApplication.dao.CustomerdbdaoImp;
import org.cap.WalletApplication.dao.Icustomercreation;
import org.cap.WalletApplication.exceptionhandling.DataInsertionException;
import org.cap.WalletApplication.exceptionhandling.InvalidAccountNumberException;
import org.cap.WalletApplication.model.Account;
import org.cap.WalletApplication.model.Address;
import org.cap.WalletApplication.model.Customer;
import org.cap.WalletApplication.model.Transaction;

public class CustomerServiceImp implements ICustomerService {
	
	
	private Icustomercreation customerdbdao;
	public CustomerServiceImp() {
		
		this.customerdbdao=new CustomerdbdaoImp();
	}
	
	@Override
	public boolean addCustomer(Customer customer)throws DataInsertionException {
		
		CustomerdbdaoImp customerdbdao=new CustomerdbdaoImp();
		return customerdbdao.addCustomer(customer);
	}

	@Override
	public boolean addAddress(Customer customer) {
		CustomerdbdaoImp customerdbdao=new CustomerdbdaoImp();
		return customerdbdao.addAddress(customer);
	}


	@Override
	public Customer loginCustomer(String customer_emailId, String password) {
		return customerdbdao.loginCustomer(customer_emailId, password);
	}

	@Override
	public Account createAccount(Account account, Customer customer) {
		return customerdbdao.createAccount(account, customer);
	}


	public Account findAccount(int accountId) {
		
		return customerdbdao.findAccount(accountId);
	}
	
	@Override
	public List<Account> getAllAccountByCustomerID(int customerID, String type) {
		
		return customerdbdao.getAllAccountByCustomerID(customerID, type);
	}
	@Override
	public Account depositOrWithdrawAmount(Account account, double amount,String type) throws InvalidAccountNumberException {
		
		return customerdbdao.depositOrWithdrawAmount(account, amount, type);
	}
	
	@Override
	public List<Transaction> getTransactionSummary(int customerID, LocalDate fromDate, LocalDate toDate) {
		System.out.println(customerID+" "+fromDate+" "+toDate);
		return customerdbdao.getTransactionSummary(customerID,fromDate, toDate );
	}
	@Override
	public Account fundtransfer(int fromAcc, int toAcc, double amount) {
	
		return customerdbdao.funtransfer(fromAcc,toAcc,amount);
	}

	@Override
	public Account getAccountByAccountNo(int accNo) {
		
		return customerdbdao.findAccount(accNo);
	}
	
	
}


