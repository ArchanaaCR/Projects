package org.cap.demo.test;



import java.time.LocalDate;
import java.time.LocalDateTime;

import org.cap.WalletApplication.dao.Icustomercreation;
import org.cap.WalletApplication.exceptionhandling.DataInsertionException;
import org.cap.WalletApplication.exceptionhandling.InvalidAccountNumberException;
import org.cap.WalletApplication.model.Account;
import org.cap.WalletApplication.model.AccountType;
import org.cap.WalletApplication.model.Address;
import org.cap.WalletApplication.model.Customer;
import org.cap.WalletApplication.model.Transaction;
import org.cap.WalletApplication.model.TransactionType;
import org.cap.WalletApplication.service.CustomerServiceImp;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class TestCaseWalletApp {

	@Mock
	private Icustomercreation customerdbimp;

	@InjectMocks
	private CustomerServiceImp customerserviceimp; 


	@Test
	void test_addCustomer() throws DataInsertionException
	{
		Customer customer=new Customer(); Address address=new Address();
		customer.setCustomerFirstName("Chitra");
		customer.setCustomerLastName("R");
		customer.setCustomer_emailId("chitra@gmail.in");
		customer.setPassword("Chitra@23");
		customer.setConfirmPassword("Chitra@23");
		address.setAddressId(1);
		address.setAddressLine1("West");
		address.setAddressLine2("Ring");
		address.setCity("Pod");
		address.setState("Pondy");
		address.setZipCode("1234");
		customer.setAddress(address);

		Mockito.when(customerdbimp.addCustomer(customer)).thenReturn(true);
		customerserviceimp.addCustomer(customer);
		Mockito.verify(customerdbimp).addCustomer(customer);	
		
	}
	@Test
	void test_createAccount()
	{
		Account account=new Account(1,AccountType.SAVING,2800,LocalDate.of(2020, 12, 12),"Thanks");
		Customer customer=new Customer();
		customer.setCustomerFirstName("Chitra");
		customer.setCustomerLastName("R");
		customer.setCustomer_emailId("chitra@gmail.in");
		customer.setPassword("Chitra@23");
		customer.setConfirmPassword("Chitra@23");
		Mockito.when(customerdbimp.createAccount(account, customer)).thenReturn(account);
		customerserviceimp.createAccount(account, customer);
		Mockito.verify(customerdbimp).createAccount(account, customer);
	}

	@Test
	void test_loginCustomer(){

		Customer customer=new Customer();
		customer.getCustomer_emailId();
		customer.getConfirmPassword();
		Mockito.when(customerdbimp.loginCustomer("chitra@gmail.in", "Chitra@23")).thenReturn(customer);
		customerserviceimp.loginCustomer("chitra@gmail.in", "Chitra@23");
		Mockito.verify(customerdbimp).loginCustomer("chitra@gmail.in", "Chitra@23");
	}


	@Test
	void test_depositAndWithdraw()throws InvalidAccountNumberException
	{

		Account account=new Account(1,AccountType.SAVING,2800,LocalDate.of(2020, 12, 12),"Thanks");


		Transaction transaction=new Transaction(1,TransactionType.DEBIT,  LocalDateTime.now(),"withdraw money",300.0);

		Mockito.when(customerdbimp.depositOrWithdrawAmount(account, 200.00, "DEBIT")).thenReturn(account);
		customerserviceimp.depositOrWithdrawAmount(account, 200.00, "DEBIT");
		Mockito.verify(customerdbimp).depositOrWithdrawAmount(account, 200.00, "DEBIT");

	}
	@Test
	void test_deposit_and_withdraw() throws InvalidAccountNumberException {
		Account account=new Account(1,AccountType.CURRENT,5000.0,LocalDate.of(2022, 01, 02),"Opening an account");
		Transaction transaction=new Transaction(1,TransactionType.DEBIT,  LocalDateTime.now(),"withdraw money",300.0);
		Mockito.when(customerdbimp.depositOrWithdrawAmount(account, 1000.00, "CREDIT")).thenReturn(account);
		customerserviceimp.depositOrWithdrawAmount(account, 1000.00, "CREDIT");
		Mockito.verify(customerdbimp).depositOrWithdrawAmount(account, 1000.00, "CREDIT");
	}

	@Test
	void tesct_viewAllAccounts()
	{
		Account account=new Account();
		account.getAccountId();
		
		//Mockito.when(customerdbimp.getAllAccountByCustomer(1, account)).thenReturn(account);
		

	}
	@Test
	void test_getAccountByAccountNo() {
	Account account=new Account();
	int accountno=1;
	Mockito.when(((CustomerServiceImp) customerdbimp).getAccountByAccountNo(accountno)).thenReturn(account);
	customerserviceimp.getAccountByAccountNo(accountno);
	((CustomerServiceImp) Mockito.verify(customerdbimp)).getAccountByAccountNo(accountno);
	}


}
